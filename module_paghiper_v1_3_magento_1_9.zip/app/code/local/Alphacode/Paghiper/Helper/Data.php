<?php 

/**
* Project: Modulo de Boleto Bancario - PagHiper 
*
* @author Alphacode - IT Solutions <www.alphacode.com.br>
*
*/ 

class Alphacode_Paghiper_Helper_Data extends Mage_Payment_Helper_Data {} ?>