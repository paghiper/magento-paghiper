<?php 

/**
* Project: Modulo de Boleto Bancario - PagHiper 
*
* @author Alphacode - IT Solutions <www.alphacode.com.br>
*
*/

class Alphacode_Paghiper_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        return true;
    }
}